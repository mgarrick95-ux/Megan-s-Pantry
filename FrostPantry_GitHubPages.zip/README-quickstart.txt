FrostPantry — GitHub Pages Quickstart

1) Create a new public repo on GitHub (e.g., `frostpantry`).
2) Upload the entire **docs/** folder contents to the root of your repo (keep the folder name `docs`).
3) In the repo, go to **Settings → Pages**:
   - **Source:** Deploy from a branch
   - **Branch:** `main` (or `master`), **/docs** folder → Save
4) Wait ~30 seconds. Your app will be live at:
   https://<your-username>.github.io/<repo-name>/

On your phone:
- Open that URL → browser menu → **Add to Home screen**.
- Works offline, saves locally, and updates automatically when you push changes.
